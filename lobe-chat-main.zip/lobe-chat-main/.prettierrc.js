module.exports = require('@lobehub/lint').prettier;
