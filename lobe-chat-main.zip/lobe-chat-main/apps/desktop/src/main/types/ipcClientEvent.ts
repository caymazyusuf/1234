export interface IpcClientEventSender {
  identifier: string;
}
