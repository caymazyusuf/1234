export const isDev = process.env.NODE_ENV === 'development';

export const OFFICIAL_CLOUD_SERVER = process.env.OFFICIAL_CLOUD_SERVER || 'https://lobechat.com';
